setwd("C:\\Users\\VICTUS\\Desktop\\IT24101617")
#binomial distribution
pbinom(47,50,0.85,lower.tail = FALSE)
1-pbinom(47,50,0.85,lower.tail = TRUE)
#number of customer calls per hour
#poisson distribution
#number of customer calls per hour
#poisson distribution
dpois(15,12)
